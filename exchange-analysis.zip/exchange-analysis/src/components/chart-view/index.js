export { default } from './chart-view';
